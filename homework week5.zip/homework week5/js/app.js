// Exercise 5.3
const movieDetails = (title, released) => {
  return `${title} has been released in ${released}.`;
};
movie1 = movieDetails("Pride and Prejudice", 2015);
console.log(movie1);

//Exercise 5.4
const shoppingCart = (item, cost, balance) => {
  if (cost < balance) {
    return `I can afford to buy this ${item}!`;
  } else {
    return `This ${item} is too expensive for me unfortunately.`;
  }
};
console.log(shoppingCart("dress", 150, 1000));

//Exercise 5.5
// FUNCTIONS EXERCISE

// 1. Write a function that reverses a string
const reverseString = (str) => {
  return str.split("").reverse().join("");
};
console.log(reverseString("apple"));

// 2. Write a function that sorts a string in alphabetical order
const sortAlphabets = (text) => {
  return text.split("").sort().join("");
};
console.log(sortAlphabets("apple"));
// 3. Write a function that loops over an array or Strings and capitalises each one before returning the array
const days = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

let capitalize = days.map(
  (day) => day.charAt(0).toUpperCase() + day.slice(1).toLowerCase()
);

console.log(capitalize);

// 4. Write a function that console logs the data type of the aruments
const type = (arg) => {
  console.log(typeof arg);
};
type("apple");

// 5. Write a function that returns the length of the longest word in a sentence
function findLongestWord(str) {
  var strSplit = str.split(" ");
  var longestWord = 0;
  for (var i = 0; i < strSplit.length; i++) {
    if (strSplit[i].length > longestWord) {
      longestWord = strSplit[i].length;
    }
  }
  return longestWord;
}
console.log(findLongestWord("The quick brown fox jumped over the lazy dog"));
